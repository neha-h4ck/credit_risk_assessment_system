"""
Model Evaluation Module for Credit Risk Assessment System
----------------------------------------------------------
Computes classification evaluation metrics:
Accuracy, Precision, Recall, F1-Score, ROC-AUC, Classification Report,
Confusion Matrix, ROC Curve, and Logistic Regression Coefficient Importance.
Supports Matplotlib, Seaborn, Plotly, and text-based metrics summaries.
"""

import sys
import math
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))


def calculate_metrics(y_true, y_pred, y_prob):
    """
    Computes key classification metrics: Accuracy, Precision, Recall, F1-Score, and ROC-AUC.
    """
    try:
        from sklearn.metrics import (
            accuracy_score, precision_score, recall_score,
            f1_score, roc_auc_score, confusion_matrix, classification_report
        )

        acc = accuracy_score(y_true, y_pred)
        prec = precision_score(y_true, y_pred, zero_division=0)
        rec = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        try:
            auc = roc_auc_score(y_true, y_prob)
        except Exception:
            auc = 0.5

        cm = confusion_matrix(y_true, y_pred).tolist()
        report = classification_report(y_true, y_pred, target_names=['Good Credit (0)', 'Bad Credit (1)'])

        return {
            'accuracy': float(acc),
            'precision': float(prec),
            'recall': float(rec),
            'f1_score': float(f1),
            'roc_auc': float(auc),
            'confusion_matrix': cm,
            'classification_report': report
        }

    except ImportError:
        # Pure python metric calculation
        tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 1)
        tn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 0)
        fp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 1)
        fn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 0)

        total = len(y_true)
        acc = (tp + tn) / total if total > 0 else 0.0
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * (prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0

        # Simple ROC-AUC trapezoidal calculation in pure python
        paired = sorted(zip(y_prob, y_true), key=lambda x: x[0], reverse=True)
        num_pos = sum(y_true)
        num_neg = total - num_pos
        auc = 0.5
        if num_pos > 0 and num_neg > 0:
            fp_count = 0
            tp_count = 0
            auc_accum = 0
            prev_fp = 0
            prev_tp = 0
            for score, label in paired:
                if label == 1:
                    tp_count += 1
                else:
                    fp_count += 1
                    auc_accum += (tp_count + prev_tp) / 2.0
                    prev_tp = tp_count
            auc = auc_accum / (num_pos * num_neg) if (num_pos * num_neg) > 0 else 0.5

        cm = [[tn, fp], [fn, tp]]
        report = (
            f"Precision: {prec:.4f}, Recall: {rec:.4f}, F1: {f1:.4f}\n"
            f"Accuracy: {acc:.4f}, ROC-AUC: {auc:.4f}"
        )

        return {
            'accuracy': acc,
            'precision': prec,
            'recall': rec,
            'f1_score': f1,
            'roc_auc': auc,
            'confusion_matrix': cm,
            'classification_report': report
        }


def print_evaluation_summary(metrics, model_name="Logistic Regression"):
    """
    Prints formatted evaluation summary to terminal.
    """
    print("=" * 60)
    print(f"        MODEL EVALUATION SUMMARY ({model_name.upper()})")
    print("=" * 60)
    print(f"Accuracy  : {metrics['accuracy']:.4f} ({metrics['accuracy']*100:.2f}%)")
    print(f"Precision : {metrics['precision']:.4f}")
    print(f"Recall    : {metrics['recall']:.4f}")
    print(f"F1 Score  : {metrics['f1_score']:.4f}")
    print(f"ROC-AUC   : {metrics['roc_auc']:.4f}")
    print("-" * 60)
    print("Confusion Matrix:")
    cm = metrics['confusion_matrix']
    print(f"  [ TN: {cm[0][0]:<4} | FP: {cm[0][1]:<4} ]")
    print(f"  [ FN: {cm[1][0]:<4} | TP: {cm[1][1]:<4} ]")
    print("-" * 60)
    print("Classification Report:")
    print(metrics['classification_report'])
    print("=" * 60 + "\n")


def generate_evaluation_plots(y_true, y_prob, coefficients=None, feature_names=None, save_dir=None):
    """
    Generates and optionally saves metric evaluation charts:
    Confusion Matrix, ROC Curve, and Logistic Regression Coefficients.
    """
    try:
        import matplotlib.pyplot as plt
        import seaborn as sns
        from sklearn.metrics import confusion_matrix, roc_curve

        if save_dir:
            save_dir = Path(save_dir)
            save_dir.mkdir(parents=True, exist_ok=True)

        fig, axes = plt.subplots(1, 3, figsize=(18, 5))
        sns.set_style('whitegrid')

        # 1. Confusion Matrix Heatmap
        y_pred = [1 if p >= 0.5 else 0 for p in y_prob]
        cm = confusion_matrix(y_true, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0],
                    xticklabels=['Good (0)', 'Bad (1)'], yticklabels=['Good (0)', 'Bad (1)'])
        axes[0].set_title('Confusion Matrix')
        axes[0].set_xlabel('Predicted Label')
        axes[0].set_ylabel('True Label')

        # 2. ROC Curve
        fpr, tpr, _ = roc_curve(y_true, y_prob)
        axes[1].plot(fpr, tpr, color='darkorange', lw=2, label='ROC Curve')
        axes[1].plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Baseline')
        axes[1].set_xlim([0.0, 1.0])
        axes[1].set_ylim([0.0, 1.05])
        axes[1].set_xlabel('False Positive Rate')
        axes[1].set_ylabel('True Positive Rate')
        axes[1].set_title('ROC Curve')
        axes[1].legend(loc='lower right')

        # 3. Top Logistic Regression Coefficients
        if coefficients is not None and feature_names is not None:
            # Sort coefficients by absolute value
            coef_pairs = sorted(zip(feature_names, coefficients), key=lambda x: abs(x[1]), reverse=True)[:10]
            top_features, top_coefs = zip(*coef_pairs) if coef_pairs else ([], [])
            colors = ['crimson' if c > 0 else 'teal' for c in top_coefs]
            axes[2].barh(range(len(top_coefs)), top_coefs, color=colors, align='center')
            axes[2].set_yticks(range(len(top_coefs)))
            axes[2].set_yticklabels(top_features)
            axes[2].invert_yaxis()
            axes[2].set_xlabel('Coefficient Magnitude (Log-Odds)')
            axes[2].set_title('Top 10 Model Coefficients\n(Direction & Strength of Association)')

        plt.tight_layout()
        if save_dir:
            plot_path = save_dir / "model_evaluation_dashboard.png"
            plt.savefig(plot_path, dpi=300)
            print(f"Evaluation charts saved to {plot_path}")
        plt.close()

    except ImportError:
        print("Matplotlib/Seaborn not installed. Skipping chart PNG export.")


if __name__ == "__main__":
    print("Testing Model Evaluation Module...")
    test_y_true = [0, 0, 0, 0, 1, 1, 1, 1]
    test_y_pred = [0, 0, 0, 1, 1, 1, 1, 0]
    test_y_prob = [0.1, 0.2, 0.3, 0.6, 0.8, 0.9, 0.75, 0.4]

    m = calculate_metrics(test_y_true, test_y_pred, test_y_prob)
    print_evaluation_summary(m, "Test Model")
    print("Model Evaluation Module verified successfully!")
