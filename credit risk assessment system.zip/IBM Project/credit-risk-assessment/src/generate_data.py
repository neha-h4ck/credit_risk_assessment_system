import os
import random
import csv
import math
from pathlib import Path

random.seed(42)

# Save credit_data.csv in project data folder
data_dir = Path(__file__).resolve().parent.parent / "data"
data_dir.mkdir(parents=True, exist_ok=True)
csv_path = data_dir / "credit_data.csv"

employment_options = ['Employed', 'Self-Employed', 'Unemployed', 'Student', 'Retired']
housing_options = ['Own', 'Rent', 'Mortgage', 'Other']
card_type_options = ['Standard', 'Rewards / Gold', 'Platinum / Premium', 'Business Card']

header = [
    'age', 'annual_income', 'credit_score', 'credit_card_limit_requested',
    'employment_status', 'housing_status', 'existing_credit_cards',
    'card_utilization_ratio', 'late_payments_last_2yrs', 'debt_to_income_ratio',
    'card_type_requested', 'dependents', 'derogatory_reports', 'target'
]

rows = []
for i in range(1000):
    age = random.randint(18, 75)
    employment = random.choices(employment_options, weights=[0.65, 0.18, 0.05, 0.05, 0.07])[0]
    housing = random.choices(housing_options, weights=[0.42, 0.38, 0.16, 0.04])[0]
    dependents = random.choices([0, 1, 2, 3, 4], weights=[0.45, 0.25, 0.20, 0.07, 0.03])[0]
    
    # Financial indicators
    if employment == 'Employed':
        annual_income = round(random.uniform(25000, 180000), -2)
    elif employment == 'Self-Employed':
        annual_income = round(random.uniform(20000, 220000), -2)
    elif employment == 'Retired':
        annual_income = round(random.uniform(18000, 75000), -2)
    elif employment == 'Student':
        annual_income = round(random.uniform(8000, 25000), -2)
    else:
        annual_income = round(random.uniform(5000, 20000), -2)

    # Credit score correlated with income and employment
    base_score = random.randint(350, 820)
    if annual_income > 75000:
        credit_score = min(max(base_score + random.randint(30, 80), 300), 850)
    elif annual_income < 20000:
        credit_score = min(max(base_score - random.randint(20, 60), 300), 850)
    else:
        credit_score = min(max(base_score, 300), 850)

    # Requested limit proportional to income
    limit_factor = random.uniform(0.05, 0.35)
    credit_card_limit_requested = round(min(max(annual_income * limit_factor, 1000), 50000), -2)
    
    card_type = random.choices(card_type_options, weights=[0.45, 0.30, 0.15, 0.10])[0]
    existing_credit_cards = random.choices([0, 1, 2, 3, 4, 5], weights=[0.15, 0.35, 0.25, 0.15, 0.07, 0.03])[0]
    
    card_utilization_ratio = round(random.uniform(5.0, 95.0), 1)
    late_payments_last_2yrs = random.choices([0, 1, 2, 3, 4], weights=[0.68, 0.18, 0.08, 0.04, 0.02])[0]
    debt_to_income_ratio = round(random.uniform(8.0, 65.0), 1)
    derogatory_reports = random.choices([0, 1, 2], weights=[0.82, 0.13, 0.05])[0]

    # Calculate credit card default risk score for logistic probability target
    risk_score = 0.0
    
    if credit_score < 580: risk_score += 1.5
    elif credit_score < 670: risk_score += 0.7
    elif credit_score >= 740: risk_score -= 1.0

    if card_utilization_ratio > 70.0: risk_score += 1.2
    elif card_utilization_ratio > 40.0: risk_score += 0.5
    elif card_utilization_ratio < 20.0: risk_score -= 0.6

    if debt_to_income_ratio > 45.0: risk_score += 1.0
    if late_payments_last_2yrs > 0: risk_score += 0.8 * late_payments_last_2yrs
    if derogatory_reports > 0: risk_score += 1.1 * derogatory_reports

    if employment == 'Unemployed': risk_score += 1.2
    elif employment in ['Employed', 'Self-Employed'] and annual_income > 80000: risk_score -= 0.8

    if credit_card_limit_requested > (annual_income * 0.3): risk_score += 0.8

    prob_bad = 1.0 / (1.0 + math.exp(-(risk_score - 0.4)))
    target = 1 if random.random() < prob_bad else 0

    rows.append([
        age, annual_income, credit_score, credit_card_limit_requested,
        employment, housing, existing_credit_cards, card_utilization_ratio,
        late_payments_last_2yrs, debt_to_income_ratio, card_type,
        dependents, derogatory_reports, target
    ])

with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

print(f"Credit Card Risk Dataset successfully generated at: {csv_path} with {len(rows)} records.")
