"""
Data Preprocessing Module for Credit Card Risk Assessment System
------------------------------------------------------------------
Handles dataset loading, missing value inspection & imputation,
One-Hot Encoding of categorical variables, Standard Scaling of numerical variables,
and leakage-free train/test splitting for Credit Card Risk Assessment.
"""

import sys
import math
import random
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

NUMERICAL_FEATURES = [
    'age', 'annual_income', 'credit_score', 'credit_card_limit_requested',
    'existing_credit_cards', 'card_utilization_ratio', 'late_payments_last_2yrs',
    'debt_to_income_ratio', 'dependents', 'derogatory_reports'
]

CATEGORICAL_FEATURES = [
    'employment_status', 'housing_status', 'card_type_requested'
]

TARGET_COLUMN = 'target'


class CustomPreprocessor:
    """
    Pure-Python fallback preprocessor combining StandardScaler for numerical columns
    and OneHotEncoder for categorical columns to guarantee leak-free preprocessing.
    """
    def __init__(self):
        self.num_cols = NUMERICAL_FEATURES
        self.cat_cols = CATEGORICAL_FEATURES
        self.num_means = {}
        self.num_stds = {}
        self.cat_categories = {}
        self.feature_names = []

    def _normalize_data_input(self, data):
        """Converts DataFrames or single dicts to a list of dicts."""
        if hasattr(data, 'to_dict'):
            return data.to_dict(orient='records')
        elif isinstance(data, dict):
            return [data]
        return data

    def fit(self, data):
        data = self._normalize_data_input(data)
        
        # Calculate means and stds for numerical columns
        for col in self.num_cols:
            vals = [float(row[col]) for row in data if col in row and row[col] is not None]
            if not vals:
                mean = 0.0
                std = 1.0
            else:
                mean = sum(vals) / len(vals)
                variance = sum((x - mean) ** 2 for x in vals) / len(vals)
                std = math.sqrt(variance) if variance > 0 else 1.0
            self.num_means[col] = mean
            self.num_stds[col] = std

        # Collect unique categories for categorical columns
        for col in self.cat_cols:
            unique_cats = sorted(list(set(str(row[col]) for row in data if col in row and row[col] is not None)))
            self.cat_categories[col] = unique_cats

        # Generate output feature names
        feature_names = [f"num__{col}" for col in self.num_cols]
        for col in self.cat_cols:
            for cat in self.cat_categories[col]:
                feature_names.append(f"cat__{col}_{cat}")
        self.feature_names = feature_names
        return self

    def transform(self, data):
        data = self._normalize_data_input(data)
        transformed = []
        for row in data:
            row_vec = []
            # Numerical scaled values
            for col in self.num_cols:
                val = float(row.get(col, self.num_means.get(col, 0.0)))
                mean = self.num_means.get(col, 0.0)
                std = self.num_stds.get(col, 1.0)
                scaled = (val - mean) / std
                row_vec.append(scaled)
            # Categorical one-hot values
            for col in self.cat_cols:
                val = str(row.get(col, ''))
                for cat in self.cat_categories.get(col, []):
                    row_vec.append(1.0 if val == cat else 0.0)
            transformed.append(row_vec)
        return transformed

    def fit_transform(self, data):
        self.fit(data)
        return self.transform(data)

    def get_feature_names_out(self):
        return self.feature_names


def load_data(filepath=None):
    """
    Load dataset from CSV file and display basic structural summaries.
    """
    if filepath is None:
        filepath = project_root / "data" / "credit_data.csv"
    
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"Dataset not found at {filepath}")
    
    try:
        import pandas as pd
        df = pd.read_csv(filepath)
        print("=== Credit Card Risk Dataset Summary ===")
        print(f"File Path: {filepath}")
        print(f"Shape: {df.shape[0]} rows, {df.shape[1]} columns")
        print("\nMissing Values Count per Column:")
        print(df.isnull().sum())
        print("=======================================\n")
        return df
    except ImportError:
        import csv
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = list(csv.DictReader(f))
        print("=== Credit Card Risk Dataset Summary ===")
        print(f"File Path: {filepath}")
        print(f"Shape: {len(reader)} rows, {len(reader[0])} columns")
        print("Loaded dataset via standard Python CSV module.\n")
        return reader


def prepare_train_test_data(df, test_size=0.2, random_state=42):
    """
    Separates X and y, splits dataset into stratified train and test sets,
    and fits the preprocessing pipeline strictly on training data to prevent leakage.
    """
    try:
        import pandas as pd
        from sklearn.model_selection import train_test_split
        from sklearn.compose import ColumnTransformer
        from sklearn.pipeline import Pipeline
        from sklearn.impute import SimpleImputer
        from sklearn.preprocessing import StandardScaler, OneHotEncoder

        if isinstance(df, list):
            df = pd.DataFrame(df)

        X = df[NUMERICAL_FEATURES + CATEGORICAL_FEATURES]
        y = df[TARGET_COLUMN].astype(int)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y,
            test_size=test_size,
            random_state=random_state,
            stratify=y
        )

        num_pipeline = Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])

        cat_pipeline = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
        ])

        preprocessor = ColumnTransformer(
            transformers=[
                ('num', num_pipeline, NUMERICAL_FEATURES),
                ('cat', cat_pipeline, CATEGORICAL_FEATURES)
            ],
            remainder='drop'
        )

        X_train_processed = preprocessor.fit_transform(X_train)
        X_test_processed = preprocessor.transform(X_test)

        try:
            feature_names = preprocessor.get_feature_names_out().tolist()
        except AttributeError:
            cat_encoder = preprocessor.named_transformers_['cat'].named_steps['onehot']
            cat_feature_names = cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES).tolist()
            feature_names = NUMERICAL_FEATURES + cat_feature_names

        scaler_component = preprocessor.named_transformers_['num'].named_steps['scaler']

        return {
            'X_train': X_train,
            'X_test': X_test,
            'y_train': y_train,
            'y_test': y_test,
            'X_train_processed': X_train_processed,
            'X_test_processed': X_test_processed,
            'preprocessor': preprocessor,
            'scaler': scaler_component,
            'feature_names': feature_names
        }

    except ImportError:
        print("Scikit-Learn/Pandas not found. Using Pure-Python preprocessor fallback.")
        random.seed(random_state)
        data = list(df)
        
        good = [r for r in data if int(r[TARGET_COLUMN]) == 0]
        bad = [r for r in data if int(r[TARGET_COLUMN]) == 1]
        random.shuffle(good)
        random.shuffle(bad)

        n_good_test = int(len(good) * test_size)
        n_bad_test = int(len(bad) * test_size)

        test_data = good[:n_good_test] + bad[:n_bad_test]
        train_data = good[n_good_test:] + bad[n_bad_test:]

        random.shuffle(train_data)
        random.shuffle(test_data)

        y_train = [int(r[TARGET_COLUMN]) for r in train_data]
        y_test = [int(r[TARGET_COLUMN]) for r in test_data]

        preprocessor = CustomPreprocessor()
        X_train_processed = preprocessor.fit_transform(train_data)
        X_test_processed = preprocessor.transform(test_data)

        return {
            'X_train': train_data,
            'X_test': test_data,
            'y_train': y_train,
            'y_test': y_test,
            'X_train_processed': X_train_processed,
            'X_test_processed': X_test_processed,
            'preprocessor': preprocessor,
            'scaler': preprocessor,
            'feature_names': preprocessor.get_feature_names_out()
        }


if __name__ == "__main__":
    print("Testing Data Preprocessing Module...")
    data = load_data()
    splits = prepare_train_test_data(data)
    print(f"Training set processed shape: {len(splits['X_train_processed'])} rows, {len(splits['X_train_processed'][0])} features")
    print(f"Testing set processed shape: {len(splits['X_test_processed'])} rows, {len(splits['X_test_processed'][0])} features")
    print(f"Total encoded features: {len(splits['feature_names'])}")
    print("Data Preprocessing Module verified successfully!")
