"""
Model Training Module for Credit Risk Assessment System
--------------------------------------------------------
Trains Logistic Regression (primary classifier) and Random Forest Classifier,
evaluates both models on stratified test data, selects and logs performance,
and exports model artifacts (credit_risk_model.pkl, preprocessor.pkl, scaler.pkl) using Joblib / Pickle.
"""

import sys
import math
import pickle
import json
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from src.data_preprocessing import load_data, prepare_train_test_data
from src.evaluation import calculate_metrics, print_evaluation_summary, generate_evaluation_plots


class PurePythonLogisticRegression:
    """
    Pure-Python Logistic Regression model trained via mini-batch gradient descent
    with L2 regularization and balanced class weighting fallback.
    """
    def __init__(self, lr=0.05, max_iter=800, l2_reg=0.01, random_state=42):
        self.lr = lr
        self.max_iter = max_iter
        self.l2_reg = l2_reg
        self.random_state = random_state
        self.weights = []
        self.intercept = 0.0
        self.coef_ = []

    def _sigmoid(self, z):
        return 1.0 / (1.0 + math.exp(-max(min(z, 20.0), -20.0)))

    def fit(self, X, y):
        n_samples = len(X)
        n_features = len(X[0])
        
        # Calculate class weights for balanced class distribution
        n_pos = sum(y)
        n_neg = n_samples - n_pos
        w_pos = n_samples / (2.0 * n_pos) if n_pos > 0 else 1.0
        w_neg = n_samples / (2.0 * n_neg) if n_neg > 0 else 1.0

        # Initialize weights
        import random
        random.seed(self.random_state)
        self.weights = [(random.random() - 0.5) * 0.01 for _ in range(n_features)]
        self.intercept = 0.0

        for iteration in range(self.max_iter):
            dw = [0.0] * n_features
            db = 0.0

            for i in range(n_samples):
                xi = X[i]
                yi = y[i]
                sample_weight = w_pos if yi == 1 else w_neg

                linear = sum(w * x for w, x in zip(self.weights, xi)) + self.intercept
                pred = self._sigmoid(linear)
                err = (pred - yi) * sample_weight

                for j in range(n_features):
                    dw[j] += err * xi[j]
                db += err

            for j in range(n_features):
                dw[j] = (dw[j] / n_samples) + self.l2_reg * self.weights[j]
                self.weights[j] -= self.lr * dw[j]

            db = db / n_samples
            self.intercept -= self.lr * db

        self.coef_ = [list(self.weights)]
        return self

    def predict_proba(self, X):
        probs = []
        for xi in X:
            linear = sum(w * x for w, x in zip(self.weights, xi)) + self.intercept
            p_bad = self._sigmoid(linear)
            probs.append([1.0 - p_bad, p_bad])
        return probs

    def predict(self, X, threshold=0.5):
        probs = self.predict_proba(X)
        return [1 if p[1] >= threshold else 0 for p in probs]


def save_artifacts(model, preprocessor, scaler, models_dir=None):
    """
    Saves model, preprocessor, and scaler binaries into the models/ directory.
    Uses Joblib if available, falling back to pickle.
    """
    if models_dir is None:
        models_dir = project_root / "models"
    
    models_dir = Path(models_dir)
    models_dir.mkdir(parents=True, exist_ok=True)

    model_path = models_dir / "credit_risk_model.pkl"
    preprocessor_path = models_dir / "preprocessor.pkl"
    scaler_path = models_dir / "scaler.pkl"

    try:
        import joblib
        joblib.dump(model, model_path)
        joblib.dump(preprocessor, preprocessor_path)
        joblib.dump(scaler, scaler_path)
        print(f"Artifacts saved via Joblib to: {models_dir}")
    except ImportError:
        with open(model_path, 'wb') as f:
            pickle.dump(model, f)
        with open(preprocessor_path, 'wb') as f:
            pickle.dump(preprocessor, f)
        with open(scaler_path, 'wb') as f:
            pickle.dump(scaler, f)
        print(f"Artifacts saved via Pickle fallback to: {models_dir}")

    return {
        'model_path': str(model_path),
        'preprocessor_path': str(preprocessor_path),
        'scaler_path': str(scaler_path)
    }


def train_and_evaluate_models():
    """
    Main model training execution pipeline.
    Loads dataset, splits into train/test, trains Logistic Regression and Random Forest,
    compares metrics, saves the primary Logistic Regression model & preprocessor,
    and returns evaluation results.
    """
    print("Loading data for model training...")
    df = load_data()
    data_splits = prepare_train_test_data(df)

    X_train = data_splits['X_train_processed']
    X_test = data_splits['X_test_processed']
    y_train = data_splits['y_train']
    y_test = data_splits['y_test']
    preprocessor = data_splits['preprocessor']
    scaler = data_splits['scaler']
    feature_names = data_splits['feature_names']

    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.ensemble import RandomForestClassifier

        print("Training Logistic Regression Model (primary)...")
        log_reg = LogisticRegression(
            class_weight='balanced',
            random_state=42,
            max_iter=1000,
            C=1.0
        )
        log_reg.fit(X_train, y_train)

        lr_pred = log_reg.predict(X_test)
        lr_prob = log_reg.predict_proba(X_test)[:, 1]
        lr_metrics = calculate_metrics(y_test, lr_pred, lr_prob)
        print_evaluation_summary(lr_metrics, "Logistic Regression (Primary Model)")

        print("Training Random Forest Model (for performance comparison)...")
        rf_model = RandomForestClassifier(
            n_estimators=100,
            class_weight='balanced',
            random_state=42
        )
        rf_model.fit(X_train, y_train)

        rf_pred = rf_model.predict(X_test)
        rf_prob = rf_model.predict_proba(X_test)[:, 1]
        rf_metrics = calculate_metrics(y_test, rf_pred, rf_prob)
        print_evaluation_summary(rf_metrics, "Random Forest Classifier (Comparison)")

        print("=== Model Comparison Summary ===")
        print(f"Logistic Regression ROC-AUC: {lr_metrics['roc_auc']:.4f} | F1: {lr_metrics['f1_score']:.4f}")
        print(f"Random Forest       ROC-AUC: {rf_metrics['roc_auc']:.4f} | F1: {rf_metrics['f1_score']:.4f}")

        # Primary model selected is Logistic Regression as specified in requirements
        chosen_model = log_reg
        chosen_metrics = lr_metrics
        coefficients = log_reg.coef_[0].tolist()

        # Generate evaluation plots
        generate_evaluation_plots(
            y_test, lr_prob, coefficients=coefficients,
            feature_names=feature_names, save_dir=project_root / "models"
        )

    except ImportError:
        print("Scikit-Learn not found. Training Pure-Python Logistic Regression model...")
        py_lr = PurePythonLogisticRegression(lr=0.05, max_iter=800, l2_reg=0.01, random_state=42)
        py_lr.fit(X_train, y_train)

        probs = py_lr.predict_proba(X_test)
        lr_prob = [p[1] for p in probs]
        lr_pred = [1 if p >= 0.5 else 0 for p in lr_prob]

        chosen_metrics = calculate_metrics(y_test, lr_pred, lr_prob)
        print_evaluation_summary(chosen_metrics, "Pure-Python Logistic Regression")

        chosen_model = py_lr

    # Save artifacts
    save_paths = save_artifacts(chosen_model, preprocessor, scaler)

    return {
        'model': chosen_model,
        'preprocessor': preprocessor,
        'scaler': scaler,
        'metrics': chosen_metrics,
        'feature_names': feature_names,
        'save_paths': save_paths
    }


if __name__ == "__main__":
    print("Starting Credit Risk Model Training Pipeline...")
    results = train_and_evaluate_models()
    print("Training pipeline completed successfully!")
