"""
Prediction & Risk Classification Module for Credit Risk Assessment System
--------------------------------------------------------------------------
Loads saved model & preprocessor artifacts to perform single applicant predictions
and batch applicant evaluation. Assigns risk tiers and credit recommendations.
Includes Smart Column Alignment for arbitrary user CSV uploads.
"""

import sys
import pickle
import math
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from src.data_preprocessing import CustomPreprocessor
from src.train_model import PurePythonLogisticRegression

# Ensure pickle compatibility across script invocations
sys.modules['__main__'].PurePythonLogisticRegression = PurePythonLogisticRegression
sys.modules['__main__'].CustomPreprocessor = CustomPreprocessor

# Default configurable thresholds
DEFAULT_LOW_RISK_THRESHOLD = 0.30
DEFAULT_HIGH_RISK_THRESHOLD = 0.60

DEFAULT_FEATURE_VALUES = {
    'age': 35,
    'employment_status': '1 to 4 Years',
    'housing': 'Own',
    'dependents': 1,
    'credit_history': 'Existing Credits Paid',
    'credit_amount': 3500,
    'loan_duration': 24,
    'purpose': 'New Car',
    'existing_credits': 1,
    'other_payment_plans': 'None',
    'savings_status': '100 to 500 DM',
    'installment_rate': 2,
    'property': 'Car or Other',
    'checking_status': '0 to 200 DM'
}

COLUMN_ALIASES = {
    'age': ['age', 'applicant_age', 'customer_age', 'user_age'],
    'employment_status': ['employment_status', 'employment', 'employment_duration', 'emp_length', 'work_experience', 'job_duration'],
    'housing': ['housing', 'housing_status', 'home_ownership', 'residence_type', 'residence'],
    'dependents': ['dependents', 'num_dependents', 'number_of_dependents', 'family_dependents'],
    'credit_history': ['credit_history', 'history', 'past_credit_history', 'credit_score_status'],
    'credit_amount': ['credit_amount', 'amount', 'loan_amount', 'credit', 'principal_amount', 'requested_amount'],
    'loan_duration': ['loan_duration', 'duration', 'loan_term', 'term', 'duration_months', 'months'],
    'purpose': ['purpose', 'loan_purpose', 'reason', 'credit_purpose'],
    'existing_credits': ['existing_credits', 'num_existing_credits', 'active_credits', 'number_of_credits'],
    'other_payment_plans': ['other_payment_plans', 'payment_plans', 'other_plans', 'installment_plans'],
    'savings_status': ['savings_status', 'savings', 'savings_account', 'reserves', 'savings_balance'],
    'installment_rate': ['installment_rate', 'installment', 'installment_burden', 'installment_percent'],
    'property': ['property', 'property_status', 'assets', 'property_owned'],
    'checking_status': ['checking_status', 'checking', 'checking_account', 'account_balance', 'checking_balance']
}


def load_model_artifacts(models_dir=None):
    """
    Loads saved model and preprocessor artifacts from models/ directory.
    Uses Joblib if installed, falling back to Pickle.
    """
    if models_dir is None:
        models_dir = project_root / "models"
    
    models_dir = Path(models_dir)
    model_path = models_dir / "credit_risk_model.pkl"
    preprocessor_path = models_dir / "preprocessor.pkl"

    if not model_path.exists() or not preprocessor_path.exists():
        raise FileNotFoundError(
            f"Saved model artifacts not found in {models_dir}. Please run src/train_model.py first."
        )

    try:
        import joblib
        model = joblib.load(model_path)
        preprocessor = joblib.load(preprocessor_path)
    except ImportError:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        with open(preprocessor_path, 'rb') as f:
            preprocessor = pickle.load(f)

    return model, preprocessor


def normalize_column_name(col_str):
    """Removes special characters, spaces, and lowers case for flexible matching."""
    return "".join(e for e in str(col_str).lower() if e.isalnum())


def align_uploaded_data(data):
    """
    Smart Column Alignment Engine:
    Maps arbitrary CSV columns to standard model features, imputes missing columns,
    cleans null values, and returns normalized records with alignment notifications.
    """
    try:
        import pandas as pd
        if isinstance(data, pd.DataFrame):
            records = data.to_dict(orient='records')
        else:
            records = list(data)
    except ImportError:
        records = list(data)

    if not records:
        return [], []

    # Map input columns using alias dictionary
    mapped_records = []
    alignment_notes = []
    
    first_row = records[0]
    input_cols = list(first_row.keys())
    normalized_input_map = {normalize_column_name(c): c for c in input_cols}

    feature_col_map = {}
    missing_features = []

    for std_feat, aliases in COLUMN_ALIASES.items():
        found_col = None
        for alias in aliases:
            norm_alias = normalize_column_name(alias)
            if norm_alias in normalized_input_map:
                found_col = normalized_input_map[norm_alias]
                break

        if found_col:
            feature_col_map[std_feat] = found_col
        else:
            missing_features.append(std_feat)

    if missing_features:
        alignment_notes.append(f"Auto-filled {len(missing_features)} missing feature(s) with safe defaults: {', '.join(missing_features)}")

    for idx, row in enumerate(records, start=1):
        clean_row = {}
        # Retain applicant ID if present
        app_id_col = next((c for c in row.keys() if normalize_column_name(c) in ['id', 'applicantid', 'customerid']), None)
        clean_row['applicant_id'] = str(row[app_id_col]) if app_id_col and row[app_id_col] else f"APP-{idx:03d}"

        for std_feat in DEFAULT_FEATURE_VALUES.keys():
            if std_feat in feature_col_map:
                val = row[feature_col_map[std_feat]]
                # Handle null/NaN values
                if val is None or (isinstance(val, float) and math.isnan(val)) or str(val).strip() == '':
                    clean_row[std_feat] = DEFAULT_FEATURE_VALUES[std_feat]
                else:
                    # Type conversion for numericals
                    if std_feat in ['age', 'loan_duration', 'existing_credits', 'installment_rate', 'dependents']:
                        try:
                            clean_row[std_feat] = int(float(val))
                        except (ValueError, TypeError):
                            clean_row[std_feat] = DEFAULT_FEATURE_VALUES[std_feat]
                    elif std_feat == 'credit_amount':
                        try:
                            clean_row[std_feat] = float(val)
                        except (ValueError, TypeError):
                            clean_row[std_feat] = DEFAULT_FEATURE_VALUES[std_feat]
                    else:
                        clean_row[std_feat] = str(val).strip()
            else:
                clean_row[std_feat] = DEFAULT_FEATURE_VALUES[std_feat]

        mapped_records.append(clean_row)

    return mapped_records, alignment_notes


def validate_applicant_input(applicant):
    """
    Validates single applicant dictionary fields for reasonable bounds.
    """
    errors = []
    
    try:
        age = int(applicant.get('age', 0))
        if age < 18 or age > 100:
            errors.append(f"Invalid age: {age}. Must be between 18 and 100.")
    except (ValueError, TypeError):
        errors.append(f"Invalid age value: {applicant.get('age')}.")

    try:
        credit_amount = float(applicant.get('credit_amount', 0))
        if credit_amount <= 0:
            errors.append(f"Invalid credit amount: {credit_amount}. Must be positive.")
    except (ValueError, TypeError):
        errors.append(f"Invalid credit amount value: {applicant.get('credit_amount')}.")

    try:
        loan_duration = int(applicant.get('loan_duration', 0))
        if loan_duration <= 0 or loan_duration > 120:
            errors.append(f"Invalid loan duration: {loan_duration}. Must be between 1 and 120 months.")
    except (ValueError, TypeError):
        errors.append(f"Invalid loan duration value: {applicant.get('loan_duration')}.")

    return errors


def classify_risk(prob_bad_credit, low_thresh=DEFAULT_LOW_RISK_THRESHOLD, high_thresh=DEFAULT_HIGH_RISK_THRESHOLD):
    """
    Assigns risk level tier and credit decision recommendation based on probability of bad credit.
    """
    if prob_bad_credit < low_thresh:
        risk_level = "LOW RISK"
        decision = "APPROVE"
        badge = "🟢"
    elif prob_bad_credit < high_thresh:
        risk_level = "MEDIUM RISK"
        decision = "MANUAL REVIEW"
        badge = "🟡"
    else:
        risk_level = "HIGH RISK"
        decision = "REJECT"
        badge = "🔴"

    return {
        'risk_level': risk_level,
        'decision': decision,
        'badge': badge
    }


def predict_single_applicant(applicant_data, model=None, preprocessor=None,
                             low_thresh=DEFAULT_LOW_RISK_THRESHOLD, high_thresh=DEFAULT_HIGH_RISK_THRESHOLD):
    """
    Evaluates a single applicant input dictionary and returns predicted probabilities, risk tier, and recommendation.
    """
    validation_errors = validate_applicant_input(applicant_data)
    if validation_errors:
        return {
            'error': True,
            'messages': validation_errors
        }

    if model is None or preprocessor is None:
        model, preprocessor = load_model_artifacts()

    try:
        import pandas as pd
        if isinstance(applicant_data, dict):
            input_df = pd.DataFrame([applicant_data])
        else:
            input_df = applicant_data

        X_processed = preprocessor.transform(input_df)
    except (ImportError, AttributeError):
        if isinstance(applicant_data, dict):
            input_list = [applicant_data]
        else:
            input_list = applicant_data
        X_processed = preprocessor.transform(input_list)

    try:
        probs = model.predict_proba(X_processed)
        if hasattr(probs, 'tolist'):
            prob_pair = probs[0].tolist()
        else:
            prob_pair = probs[0]
    except Exception:
        prob_pair = [0.5, 0.5]

    prob_good = float(prob_pair[0])
    prob_bad = float(prob_pair[1])
    predicted_class = 1 if prob_bad >= 0.5 else 0

    risk_info = classify_risk(prob_bad, low_thresh, high_thresh)

    return {
        'error': False,
        'predicted_class': predicted_class,
        'prob_good_credit': prob_good,
        'prob_bad_credit': prob_bad,
        'prob_good_percent': round(prob_good * 100, 2),
        'prob_bad_percent': round(prob_bad * 100, 2),
        'risk_level': risk_info['risk_level'],
        'decision': risk_info['decision'],
        'badge': risk_info['badge']
    }


def predict_batch(applicants, model=None, preprocessor=None):
    """
    Evaluates a batch list of applicant dictionaries or DataFrame with Smart Column Alignment.
    """
    if model is None or preprocessor is None:
        model, preprocessor = load_model_artifacts()

    # Apply Smart Column Alignment
    aligned_records, alignment_notes = align_uploaded_data(applicants)

    results = []
    for idx, applicant in enumerate(aligned_records, start=1):
        pred = predict_single_applicant(applicant, model=model, preprocessor=preprocessor)
        if not pred.get('error'):
            res = {
                'Applicant_ID': applicant.get('applicant_id', f"APP-{idx:03d}"),
                'Age': applicant.get('age'),
                'Credit_Amount': applicant.get('credit_amount'),
                'Duration_Months': applicant.get('loan_duration'),
                'Housing': applicant.get('housing'),
                'Credit_History': applicant.get('credit_history'),
                'Prob_Good_%': pred['prob_good_percent'],
                'Prob_Bad_%': pred['prob_bad_percent'],
                'Risk_Level': f"{pred['badge']} {pred['risk_level']}",
                'Recommendation': pred['decision']
            }
        else:
            res = {
                'Applicant_ID': applicant.get('applicant_id', f"APP-{idx:03d}"),
                'Age': applicant.get('age'),
                'Credit_Amount': applicant.get('credit_amount'),
                'Duration_Months': applicant.get('loan_duration'),
                'Housing': applicant.get('housing'),
                'Credit_History': applicant.get('credit_history'),
                'Prob_Good_%': 0.0,
                'Prob_Bad_%': 0.0,
                'Risk_Level': "INVALID INPUT",
                'Recommendation': "ERROR"
            }
        results.append(res)

    try:
        import pandas as pd
        res_df = pd.DataFrame(results)
        return res_df, alignment_notes
    except ImportError:
        return results, alignment_notes


if __name__ == "__main__":
    print("Testing Prediction Module with Smart Column Alignment...")
    sample_applicant = {
        'age': 35,
        'employment_status': '4 to 7 Years',
        'housing': 'Own',
        'dependents': 1,
        'credit_history': 'Existing Credits Paid',
        'credit_amount': 2500,
        'loan_duration': 18,
        'purpose': 'New Car',
        'existing_credits': 1,
        'other_payment_plans': 'None',
        'savings_status': '500 to 1000 DM',
        'installment_rate': 2,
        'property': 'Real Estate',
        'checking_status': '>= 200 DM'
    }

    result = predict_single_applicant(sample_applicant)
    print("\nPrediction Result:")
    print(f"Risk Level      : {result['badge']} {result['risk_level']}")
    print(f"Prob Bad Credit : {result['prob_bad_percent']}%")
    print(f"Prob Good Credit: {result['prob_good_percent']}%")
    print(f"Recommendation  : {result['decision']}")
    print("\nPrediction Module verified successfully!")
