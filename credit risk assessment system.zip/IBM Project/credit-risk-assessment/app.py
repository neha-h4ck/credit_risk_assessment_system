"""
Streamlit Web Application for Credit Risk Assessment System
------------------------------------------------------------
Interactive machine learning dashboard providing real-time single applicant risk scoring,
batch profile processing, and model performance analytics.
"""

import sys
import os
import pickle
import json
import io
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

# Register class definitions into __main__ for pickle compatibility
from src.data_preprocessing import CustomPreprocessor
from src.train_model import PurePythonLogisticRegression

sys.modules['__main__'].PurePythonLogisticRegression = PurePythonLogisticRegression
sys.modules['__main__'].CustomPreprocessor = CustomPreprocessor

from src.predict import (
    predict_single_applicant, predict_batch, load_model_artifacts,
    DEFAULT_LOW_RISK_THRESHOLD, DEFAULT_HIGH_RISK_THRESHOLD
)
from src.data_preprocessing import load_data, prepare_train_test_data
from src.evaluation import calculate_metrics

try:
    import streamlit as st
    HAS_STREAMLIT = True
except ImportError:
    HAS_STREAMLIT = False

try:
    import plotly.graph_objects as go
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False


def render_streamlit_app():
    st.set_page_config(
        page_title="Credit Risk Assessment System",
        page_icon="💳",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    # Custom CSS for polished aesthetics
    st.markdown("""
    <style>
    .main-title {
        font-size: 2.4rem;
        font-weight: 800;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.2rem;
    }
    .disclaimer-box {
        background-color: #FEF3C7;
        border-left: 5px solid #F59E0B;
        padding: 0.8rem 1.2rem;
        border-radius: 6px;
        color: #92400E;
        font-size: 0.88rem;
        margin-bottom: 1.5rem;
    }
    .result-card {
        padding: 1.5rem;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    .low-risk-card {
        background: #ECFDF5;
        border: 2px solid #10B981;
        color: #065F46;
    }
    .medium-risk-card {
        background: #FFFBEB;
        border: 2px solid #F59E0B;
        color: #92400E;
    }
    .high-risk-card {
        background: #FEF2F2;
        border: 2px solid #EF4444;
        color: #991B1B;
    }
    .card-title {
        font-size: 0.95rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    .card-value {
        font-size: 1.8rem;
        font-weight: 800;
    }
    </style>
    """, unsafe_allow_html=True)

    st.markdown('<div class="main-title">💳 Credit Risk Assessment System</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Machine Learning Powered Credit Risk Evaluation & Decision Engine</div>', unsafe_allow_html=True)

    st.markdown("""
    <div class="disclaimer-box">
        ⚠️ <strong>Educational ML Prediction System:</strong> This application is designed solely for educational, research, and portfolio demonstration purposes. It is NOT a real-world financial lending decision tool.
    </div>
    """, unsafe_allow_html=True)

    # Sidebar Navigation
    st.sidebar.title("📌 Navigation")
    page = st.sidebar.radio("Select View:", ["Single Applicant Assessor", "Batch Profile Evaluator", "Model Analytics Dashboard"])

    # Load model artifacts safely
    model = None
    preprocessor = None
    model_loaded = False
    try:
        model, preprocessor = load_model_artifacts()
        model_loaded = True
    except Exception as e:
        st.error(f"⚠️ Model Artifact Notice: {e}")
        st.info("Attempting to re-initialize model artifacts...")
        try:
            from src.train_model import train_and_evaluate_models
            results = train_and_evaluate_models()
            model = results['model']
            preprocessor = results['preprocessor']
            model_loaded = True
            st.success("✅ Model artifacts successfully generated!")
        except Exception as ex:
            st.error(f"Failed to auto-train model: {ex}")

    if page == "Single Applicant Assessor":
        st.header("📋 Single Applicant Credit Risk Assessor")
        st.write("Enter the applicant's demographic, credit, and financial details to calculate risk tier and credit decision.")

        # Interactive Input Form
        with st.form("applicant_scoring_form", clear_on_submit=False):
            col1, col2, col3 = st.columns(3)

            with col1:
                st.subheader("1. Applicant Info")
                age = st.number_input("Age (Years)", min_value=18, max_value=100, value=35, step=1, key="input_age")
                employment_status = st.selectbox(
                    "Employment Duration",
                    ['Unemployed', '< 1 Year', '1 to 4 Years', '4 to 7 Years', '>= 7 Years'],
                    index=2, key="input_emp"
                )
                housing = st.selectbox(
                    "Housing Status",
                    ['Rent', 'Own', 'Free'],
                    index=1, key="input_housing"
                )
                dependents = st.selectbox(
                    "Number of Dependents",
                    [1, 2],
                    index=0, key="input_dep"
                )

            with col2:
                st.subheader("2. Credit Info")
                credit_history = st.selectbox(
                    "Credit History",
                    ['Critical Account', 'Delay in Payment', 'Existing Credits Paid', 'All Credits Paid', 'No Credits'],
                    index=2, key="input_hist"
                )
                credit_amount = st.number_input("Credit Amount ($ / DM)", min_value=100, max_value=25000, value=3500, step=100, key="input_amount")
                loan_duration = st.number_input("Loan Duration (Months)", min_value=3, max_value=120, value=24, step=3, key="input_duration")
                purpose = st.selectbox(
                    "Loan Purpose",
                    ['New Car', 'Used Car', 'Furniture/Equipment', 'Radio/TV', 'Domestic Appliances', 'Repairs', 'Education', 'Business', 'Others'],
                    index=0, key="input_purpose"
                )
                existing_credits = st.selectbox(
                    "Existing Credits at Bank",
                    [1, 2, 3, 4],
                    index=0, key="input_exist_cred"
                )
                other_payment_plans = st.selectbox(
                    "Other Payment Plans",
                    ['Bank', 'Stores', 'None'],
                    index=2, key="input_plans"
                )

            with col3:
                st.subheader("3. Financial Reserves")
                savings_status = st.selectbox(
                    "Savings / Financial Reserves",
                    ['< 100 DM', '100 to 500 DM', '500 to 1000 DM', '>= 1000 DM', 'Unknown/No Savings'],
                    index=1, key="input_savings"
                )
                installment_rate = st.selectbox(
                    "Installment Rate (% of Income)",
                    [1, 2, 3, 4],
                    index=1, key="input_install"
                )
                prop = st.selectbox(
                    "Property / Assets",
                    ['Real Estate', 'Building Society Savings/Life Insurance', 'Car or Other', 'Unknown/No Property'],
                    index=0, key="input_prop"
                )
                checking_status = st.selectbox(
                    "Checking Account Balance",
                    ['< 0 DM', '0 to 200 DM', '>= 200 DM', 'No Checking Account'],
                    index=1, key="input_checking"
                )

            st.markdown("---")
            submit_btn = st.form_submit_button("🔍 ASSESS CREDIT RISK", use_container_width=True)

        if submit_btn:
            if not model_loaded:
                st.error("Model is not loaded. Cannot perform prediction.")
            else:
                applicant_input = {
                    'age': age,
                    'employment_status': employment_status,
                    'housing': housing,
                    'dependents': dependents,
                    'credit_history': credit_history,
                    'credit_amount': credit_amount,
                    'loan_duration': loan_duration,
                    'purpose': purpose,
                    'existing_credits': existing_credits,
                    'other_payment_plans': other_payment_plans,
                    'savings_status': savings_status,
                    'installment_rate': installment_rate,
                    'property': prop,
                    'checking_status': checking_status
                }

                res = predict_single_applicant(applicant_input, model=model, preprocessor=preprocessor)

                if res.get('error'):
                    st.error("Input Validation Error: " + ", ".join(res['messages']))
                else:
                    st.markdown("### 📊 Assessment Output Results")

                    card_style = "low-risk-card" if res['risk_level'] == "LOW RISK" else ("medium-risk-card" if res['risk_level'] == "MEDIUM RISK" else "high-risk-card")

                    c1, c2, c3, c4 = st.columns(4)

                    with c1:
                        st.markdown(f"""
                        <div class="result-card {card_style}">
                            <div class="card-title">Risk Level</div>
                            <div class="card-value">{res['badge']} {res['risk_level']}</div>
                        </div>
                        """, unsafe_allow_html=True)

                    with c2:
                        st.markdown(f"""
                        <div class="result-card {card_style}">
                            <div class="card-title">Recommendation</div>
                            <div class="card-value">{res['decision']}</div>
                        </div>
                        """, unsafe_allow_html=True)

                    with c3:
                        st.markdown(f"""
                        <div class="result-card {card_style}">
                            <div class="card-title">Bad Credit Probability</div>
                            <div class="card-value">{res['prob_bad_percent']}%</div>
                        </div>
                        """, unsafe_allow_html=True)

                    with c4:
                        st.markdown(f"""
                        <div class="result-card {card_style}">
                            <div class="card-title">Good Credit Probability</div>
                            <div class="card-value">{res['prob_good_percent']}%</div>
                        </div>
                        """, unsafe_allow_html=True)

                    st.markdown("#### Probability Meter")
                    if HAS_PLOTLY:
                        try:
                            fig = go.Figure(go.Indicator(
                                mode="gauge+number",
                                value=res['prob_bad_percent'],
                                domain={'x': [0, 1], 'y': [0, 1]},
                                title={'text': "Estimated Default Probability (%)", 'font': {'size': 16}},
                                number={'suffix': "%", 'font': {'size': 24}},
                                gauge={
                                    'axis': {'range': [0, 100]},
                                    'bar': {'color': "black", 'thickness': 0.25},
                                    'steps': [
                                        {'range': [0, 30], 'color': "#10B981"},
                                        {'range': [30, 60], 'color': "#F59E0B"},
                                        {'range': [60, 100], 'color': "#EF4444"}
                                    ],
                                    'threshold': {
                                        'line': {'color': "darkred", 'width': 4},
                                        'thickness': 0.8,
                                        'value': res['prob_bad_percent']
                                    }
                                }
                            ))
                            fig.update_layout(height=280, margin=dict(l=20, r=20, t=40, b=20))
                            st.plotly_chart(fig, use_container_width=True)
                        except Exception:
                            st.progress(min(max(int(res['prob_bad_percent']), 0), 100))
                    else:
                        st.progress(min(max(int(res['prob_bad_percent']), 0), 100))

    elif page == "Batch Profile Evaluator":
        st.header("📂 Batch Profile Evaluator")
        st.write("Assess multiple customer applicants independently by uploading a custom CSV dataset or running sample presets.")

        tab_upload, tab_sample = st.tabs(["📤 Upload Custom CSV File", "🚀 Preset Sample Profiles"])

        with tab_upload:
            st.subheader("Upload Applicant Dataset (.csv)")
            
            # Sample CSV Template Generation
            sample_template_csv = (
                "age,employment_status,housing,dependents,credit_history,credit_amount,loan_duration,purpose,existing_credits,other_payment_plans,savings_status,installment_rate,property,checking_status\n"
                "35,4 to 7 Years,Own,1,Existing Credits Paid,3500,24,New Car,1,None,100 to 500 DM,2,Real Estate,0 to 200 DM\n"
                "48,>= 7 Years,Own,1,All Credits Paid,1500,12,Radio/TV,1,None,>= 1000 DM,1,Real Estate,>= 200 DM\n"
                "29,1 to 4 Years,Rent,2,Existing Credits Paid,12500,48,Business,3,Bank,< 100 DM,4,Car or Other,< 0 DM\n"
            )

            st.download_button(
                label="📄 Download Sample CSV Template",
                data=sample_template_csv,
                file_name="credit_applicants_sample_template.csv",
                mime="text/csv"
            )

            st.markdown("---")

            uploaded_file = st.file_uploader("Choose any CSV file containing applicant profiles:", type=["csv"])

            if uploaded_file is not None:
                try:
                    if HAS_PANDAS:
                        df_upload = pd.read_csv(uploaded_file)
                        st.success(f"Successfully loaded {len(df_upload)} applicant profiles!")
                        st.subheader("Preview of Uploaded Data")
                        st.dataframe(df_upload.head(10), use_container_width=True)

                        if st.button("🚀 PROCESS BATCH RISK EVALUATION", use_container_width=True):
                            if model_loaded:
                                results_df, notes = predict_batch(df_upload, model=model, preprocessor=preprocessor)
                                if notes:
                                    for note in notes:
                                        st.info(f"ℹ️ Smart Column Alignment: {note}")
                                st.subheader("📊 Batch Assessment Results")
                                st.dataframe(results_df, use_container_width=True)

                                # Download Results Button
                                csv_buffer = results_df.to_csv(index=False)
                                st.download_button(
                                    label="📥 Download Risk Assessment Results (CSV)",
                                    data=csv_buffer,
                                    file_name="credit_risk_assessment_results.csv",
                                    mime="text/csv",
                                    use_container_width=True
                                )
                            else:
                                st.error("Model is not loaded.")
                    else:
                        import csv
                        content = uploaded_file.getvalue().decode('utf-8')
                        reader = list(csv.DictReader(io.StringIO(content)))
                        st.success(f"Loaded {len(reader)} rows.")
                        if st.button("🚀 PROCESS BATCH RISK EVALUATION"):
                            results, notes = predict_batch(reader, model=model, preprocessor=preprocessor)
                            if notes:
                                for note in notes:
                                    st.info(f"ℹ️ {note}")
                            st.write(results)

                except Exception as e:
                    st.error(f"Error parsing uploaded CSV file: {e}")

        with tab_sample:
            st.subheader("Run 5 Preset Hypothetical Test Profiles")
            from sample_test import SAMPLE_PROFILES

            if st.button("🚀 Evaluate 5 Sample Profiles", use_container_width=True):
                if model_loaded:
                    df_results, _ = predict_batch(SAMPLE_PROFILES, model=model, preprocessor=preprocessor)
                    if HAS_PANDAS and isinstance(df_results, pd.DataFrame):
                        st.dataframe(df_results, use_container_width=True)
                    else:
                        st.write(df_results)
                else:
                    st.error("Model is not loaded.")

    elif page == "Model Analytics Dashboard":
        st.header("📈 Model Analytics & Performance Dashboard")

        try:
            df = load_data()
            splits = prepare_train_test_data(df)
            X_test = splits['X_test_processed']
            y_test = splits['y_test']

            if model_loaded:
                try:
                    probs = model.predict_proba(X_test)
                    y_prob = [p[1] for p in probs]
                    y_pred = [1 if p >= 0.5 else 0 for p in y_prob]
                except Exception:
                    y_prob = [0.5] * len(y_test)
                    y_pred = [0] * len(y_test)

                metrics = calculate_metrics(y_test, y_pred, y_prob)

                m1, m2, m3, m4, m5 = st.columns(5)
                m1.metric("Accuracy", f"{metrics['accuracy']*100:.1f}%")
                m2.metric("Precision", f"{metrics['precision']:.3f}")
                m3.metric("Recall", f"{metrics['recall']:.3f}")
                m4.metric("F1-Score", f"{metrics['f1_score']:.3f}")
                m5.metric("ROC-AUC", f"{metrics['roc_auc']:.3f}")

                st.markdown("---")

                col_left, col_right = st.columns(2)

                with col_left:
                    st.subheader("Confusion Matrix")
                    cm = metrics['confusion_matrix']
                    if HAS_PANDAS:
                        cm_df = pd.DataFrame(
                            cm,
                            index=['Actual Good (0)', 'Actual Bad (1)'],
                            columns=['Pred Good (0)', 'Pred Bad (1)']
                        )
                        st.table(cm_df)
                    else:
                        st.write(cm)

                with col_right:
                    st.subheader("Classification Report")
                    st.code(metrics['classification_report'])

        except Exception as e:
            st.error(f"Error loading analytics dashboard: {e}")


def main():
    if HAS_STREAMLIT:
        render_streamlit_app()
    else:
        print("Streamlit is not installed in current environment.")
        print("To launch UI, run: python3 -m streamlit run app.py")


if __name__ == "__main__":
    main()
