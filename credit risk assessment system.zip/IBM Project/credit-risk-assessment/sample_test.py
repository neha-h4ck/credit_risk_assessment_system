"""
Sample Test Demonstration Script for Credit Risk Assessment System
-------------------------------------------------------------------
Tests 5 hypothetical customer profiles representing distinct financial and risk categories:
1. Strong financial profile
2. Moderate financial profile
3. High credit burden
4. Poor credit history
5. Mixed/medium-risk profile
"""

import sys
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from src.predict import predict_single_applicant, predict_batch, load_model_artifacts

# Define 5 distinct hypothetical applicant profiles
SAMPLE_PROFILES = [
    {
        'profile_name': "Profile 1: Strong Financial Profile",
        'age': 48,
        'employment_status': '>= 7 Years',
        'housing': 'Own',
        'dependents': 1,
        'credit_history': 'All Credits Paid',
        'credit_amount': 1500,
        'loan_duration': 12,
        'purpose': 'New Car',
        'existing_credits': 1,
        'other_payment_plans': 'None',
        'savings_status': '>= 1000 DM',
        'installment_rate': 1,
        'property': 'Real Estate',
        'checking_status': '>= 200 DM'
    },
    {
        'profile_name': "Profile 2: Moderate Financial Profile",
        'age': 34,
        'employment_status': '1 to 4 Years',
        'housing': 'Own',
        'dependents': 1,
        'credit_history': 'Existing Credits Paid',
        'credit_amount': 3500,
        'loan_duration': 24,
        'purpose': 'Furniture/Equipment',
        'existing_credits': 1,
        'other_payment_plans': 'None',
        'savings_status': '100 to 500 DM',
        'installment_rate': 2,
        'property': 'Building Society Savings/Life Insurance',
        'checking_status': '0 to 200 DM'
    },
    {
        'profile_name': "Profile 3: High Credit Burden",
        'age': 29,
        'employment_status': '1 to 4 Years',
        'housing': 'Rent',
        'dependents': 2,
        'credit_history': 'Existing Credits Paid',
        'credit_amount': 12500,
        'loan_duration': 48,
        'purpose': 'Business',
        'existing_credits': 3,
        'other_payment_plans': 'Bank',
        'savings_status': '< 100 DM',
        'installment_rate': 4,
        'property': 'Car or Other',
        'checking_status': '< 0 DM'
    },
    {
        'profile_name': "Profile 4: Poor Credit History",
        'age': 25,
        'employment_status': '< 1 Year',
        'housing': 'Rent',
        'dependents': 1,
        'credit_history': 'Critical Account',
        'credit_amount': 7800,
        'loan_duration': 36,
        'purpose': 'Used Car',
        'existing_credits': 2,
        'other_payment_plans': 'Stores',
        'savings_status': '< 100 DM',
        'installment_rate': 4,
        'property': 'Unknown/No Property',
        'checking_status': '< 0 DM'
    },
    {
        'profile_name': "Profile 5: Mixed / Medium-Risk Profile",
        'age': 42,
        'employment_status': '4 to 7 Years',
        'housing': 'Rent',
        'dependents': 1,
        'credit_history': 'Delay in Payment',
        'credit_amount': 4200,
        'loan_duration': 18,
        'purpose': 'Radio/TV',
        'existing_credits': 2,
        'other_payment_plans': 'None',
        'savings_status': '500 to 1000 DM',
        'installment_rate': 3,
        'property': 'Car or Other',
        'checking_status': '0 to 200 DM'
    }
]


def run_sample_tests():
    """
    Executes prediction for all sample profiles and displays formatted outputs.
    """
    print("=" * 80)
    print("        CREDIT RISK ASSESSMENT SYSTEM - HYPOTHETICAL PROFILE TESTING")
    print("=" * 80 + "\n")

    model, preprocessor = load_model_artifacts()

    for prof in SAMPLE_PROFILES:
        title = prof['profile_name']
        print("-" * 70)
        print(f"📌 {title}")
        print("-" * 70)
        print(f"Age: {prof['age']} | Employment: {prof['employment_status']} | Housing: {prof['housing']}")
        print(f"Credit History: {prof['credit_history']} | Amount: ${prof['credit_amount']:,} | Duration: {prof['loan_duration']} mos")
        print(f"Checking Status: {prof['checking_status']} | Savings: {prof['savings_status']}")
        
        result = predict_single_applicant(prof, model=model, preprocessor=preprocessor)
        
        print("\nPrediction Output:")
        print(f"  Risk Level            : {result['badge']} {result['risk_level']}")
        print(f"  Probability Bad Credit: {result['prob_bad_percent']}%")
        print(f"  Probability Good Credit: {result['prob_good_percent']}%")
        print(f"  Credit Decision       : {result['decision']}")
        print()

    print("=" * 80)
    print("               BATCH PREDICTION SUMMARY TABLE")
    print("=" * 80)
    
    batch_df = predict_batch(SAMPLE_PROFILES, model=model, preprocessor=preprocessor)
    try:
        print(batch_df.to_string(index=False))
    except AttributeError:
        for r in batch_df:
            print(r)
    print("=" * 80 + "\n")


if __name__ == "__main__":
    run_sample_tests()
